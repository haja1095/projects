<?php
	session_start();
	include_once('connection.php');
	if(isset($_POST['add'])){
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
                $rollno = $_POST['rollno'];
                $department = $_POST['department'];
                $class =$_POST['class'];
		$address = $_POST['address'];
		$sql = "INSERT INTO students (firstname, lastname,rollno,department,class,address) VALUES ('$firstname', '$lastname','$rollno','$department','$class', '$address')";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Student added successfully';
		}
		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: index.php');
?>