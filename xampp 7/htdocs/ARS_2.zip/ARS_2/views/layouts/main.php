<?php

use app\assets\AppAsset;
AppAsset::register($this);

?>