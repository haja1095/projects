<script>
window.location.assign("web/");
</script>