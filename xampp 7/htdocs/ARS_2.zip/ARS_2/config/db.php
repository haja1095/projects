<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=10.100.1.8;port=5432; dbname=ecampus_prdu',
    'username' => 'postgres',
    'password' => 'kgisl',
    'charset' => 'utf8',
];
